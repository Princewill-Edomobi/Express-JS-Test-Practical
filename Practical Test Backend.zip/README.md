# Practical test - By Princewill Edomobi

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run start
```

### Frontend url 
```

'http://localhost:3000/home'
```

### Project versions
```

Node - v14.15.3
Mongodb - v4.4.2
```

### Database connection
```

mongodb://127.0.0.1/practical_test